<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

//--------- Concursos -----------
$lang['gerenciadorRelatorioCodigo'] = 'Código';
$lang['gerenciadorRelatorioNome'] = 'Nome';
$lang['gerenciadorRelatorioLink'] = 'Link';
$lang['gerenciadorRelatorioTitulo'] = 'Cadastro de Relatório';
$lang['gerenciadorRelatorioTab1'] = 'Relatório';
$lang['gerenciadorRelatorioModulosAcesso'] = 'Módulos com acesso';
$lang['gerenciadorRelatorioNomeNaoInformado'] = 'Nome deve ser informado';
$lang['gerenciadorRelatorioLinkNaoInformado'] = 'Link deve ser informado';