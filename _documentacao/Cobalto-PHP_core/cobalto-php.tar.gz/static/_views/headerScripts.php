<script>
    var BASE_URL = '<?=base_url()?>';
    var WIKI = '<?=WIKI?>';
    var PATH_COOKIE = '<?=PATH_COOKIE?>';
    var IMG = '<?=IMG?>';
    var JS = '<?=JS?>';
</script>
<link href='<?=CSS;?>/<?=(@$_COOKIE['tema'] == '' ? 'redmond' : @$_COOKIE['tema']);?>/all.css.jquery-ui.24042012153419492153.css' type='text/css' rel='stylesheet'/>
<link rel='shortcut icon' href='<?=IMG;?>/favicon.ico' type='image/ico'/>
<script type='text/javascript' src='<?=JS;?>/all.javascript.24042012153419492153.js'></script>