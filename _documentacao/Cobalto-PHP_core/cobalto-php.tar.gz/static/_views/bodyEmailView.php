<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	</head>
	<body>
		<table cellspacing="0" cellpadding="0" border="0" width="100%" style="background-color:#2E6E9E;">
			<tbody>
				<tr>
					<td style="padding:10px 10px 0px 10px">
						<table cellspacing="0" cellpadding="0" border="0" width="100%" align="center" style="font-family:'Helvetica Neue', Helvetica, Arial, sans-serif;font-size:16px;color:#333">
				      		<tbody>
								<tr>
									<td style="background-color:#fff;padding: 20px 40px;-moz-border-radius: 10px;-webkit-border-radius: 10px;">
										<table cellpadding="0" cellspacing="0" border="0" width="100%" align="center" style="margin:0 auto">
											<tbody>
												<tr>
													<td width="100px">
														<img alt="" src="<?=IMG;?>/logoufpel.png" style="display:block;border:none">
													</td>
													<td valign="middle" style="text-align: left; padding: 5px;">
														<h2 style="font-weight:normal;font-size:19px;line-height:1.2;margin:5px;color:#333!important;"><?=$MINISTERIO_DA_EDUCACAO;?></h2>
														<h2 style="font-weight:normal;font-size:19px;line-height:1.2;margin:5px;color:#333!important;">UNIVERSIDADE FEDERAL DE PELOTAS</h2>
													</td>
												</tr>
												<tr>
													<td colspan="2">
														<hr style="margin-top: 10px;border:1px solid #2E6E9E"/>
													</td>
												</tr>
											</tbody>
										</table>
										<table style="background:#FFF" width="100%" cellpadding="0" cellspacing="0" border="0">
											<tbody>
												<tr>
													<td valign="top" width="100%" style="padding-top:5px">
														<p style="text-align:justify"><?=$MENSAGEM;?></p>
													</td>
												</tr>
											</tbody>
										</table>
					      			</td>
								</tr>								
				    		</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td style="font-family:'Helvetica Neue', Helvetica, Arial, sans-serif;color:#FFF;padding:20px;text-align: right">
						<small><?=$FOOTER_COBALTO;?></small>
					</td>
				</tr>
			</tbody>
		</table>
	<body/>
</html>