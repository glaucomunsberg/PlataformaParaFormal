		</div>
		<div id="dialog-message-error" style="display:none;"><p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 0;"></span><label></label></p></div>
		<div id="dialog-message-info" style="display:none;"><p><span class="ui-icon ui-icon-info" style="float:left; margin:0 7px 0;"></span><label></label></p></div>
		<div id="dialog-confirm" style="display:none;"><p style="margin-top: 20px;"><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 0;"></span><label></label></p></div>						
		<div class="ie6-warning" style='text-align: center; clear: both; position: absolute; top: 0; z-index: 1002;'><div class="ui-widget" style="width: 800px; margin: 100px;"><div class="ui-state-error ui-corner-all" style="padding: 0 .7em;"><p><span class="ui-icon ui-icon-alert" style="float: left; margin-right: .3em;"></span><h1>Você está usando um navegador desatualizado</h1><h2><a href="http://www.updateyourbrowser.net/pt/">Para utilizar o sistema, por favor, atualize seu navegador.</a></h2></p></div></div></div>
	</body>
</html>