<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
 * Configurações
 */
$lang['configuracaoSenhaAtualAlteradaComSucesso'] = 'Senha alterada com sucesso';
$lang['configuracaoSenhaAtualDeveSerInformada'] = 'Senha atual deve ser informada';
$lang['configuracaoSenhaNovaDeveSerInformada'] = 'Nova senha deve ser informada';
$lang['configuracaoCofirmacaoSenhaDeveSerInformada'] = 'Confirmação de senha deve ser informada';
$lang['configuracaoCofirmacaoSenhaDiferenteSenhaNova'] = 'Confirmação de senha não confere com a nova senha';
$lang['configuracaoSenhaAtualNaoConfere'] = 'Senha atual não confere com a informada no sistema';