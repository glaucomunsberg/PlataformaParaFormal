<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
 * Configurações
 */
$lang['configuracaoTab0'] = 'Dados Gerais';
$lang['configuracaoTab1'] = 'Alterar Senha';
$lang['configuracaoTab2'] = 'Temas';
$lang['configuracaoSenhaAtual'] = 'Senha atual';
$lang['configuracaoSenhaNova'] = 'Nova senha';
$lang['configuracaoRepetirSenha'] = 'Repetir nova senha';
$lang['configuracaoMinhaImagem'] = 'Minha imagem';