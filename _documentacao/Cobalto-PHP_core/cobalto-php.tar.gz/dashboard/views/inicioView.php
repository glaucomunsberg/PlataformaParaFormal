<?= $this->load->view("../../static/_views/headerGlobalView"); ?>

    <?= path_bread('Início', false); ?>

<?= $this->load->view("../../static/_views/footerGlobalView"); ?>
