<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

include BASEPATH.'config/autoload.php';
array_push($autoload['language'], 'util_labels');