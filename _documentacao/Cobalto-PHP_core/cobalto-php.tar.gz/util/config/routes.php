<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$route['default_controller'] = 'util';
$route['scaffolding_trigger'] = '';