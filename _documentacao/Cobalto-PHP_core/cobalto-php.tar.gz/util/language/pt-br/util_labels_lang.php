<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['uploadTab1'] = 'Arquivo';
$lang['uploadLimpar'] = 'Limpar';
$lang['uploadIniciar'] = 'Iniciar upload';