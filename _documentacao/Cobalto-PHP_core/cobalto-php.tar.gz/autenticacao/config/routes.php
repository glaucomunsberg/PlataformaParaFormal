<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$route['default_controller'] = "login";
$route['scaffolding_trigger'] = "";